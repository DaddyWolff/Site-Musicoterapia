# site0.1
exercicio de front: css html js
Projeto de site de musicoterapia
Peguei de base um site de portfolio de programacao basico e
modifiquei do meu jeito, tbm implementei js fazendo o slider
de imagens...
